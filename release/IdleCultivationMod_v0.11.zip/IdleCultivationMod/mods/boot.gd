extends Node
# Idle Cultivation Mod - boot loader (stays fixed, everything else updates through mods.pck)
const MOD_DIR := "user://mods/"
static var real_script: Script = null

func _init() -> void:
	var dir := DirAccess.open(MOD_DIR)
	if dir != null and dir.file_exists("mods_pending.pck"):
		if dir.file_exists("mods.pck"):
			dir.remove("mods.pck")
		if dir.rename("mods_pending.pck", "mods.pck") == OK and dir.file_exists("pending_version.txt"):
			if dir.file_exists("version.txt"):
				dir.remove("version.txt")
			dir.rename("pending_version.txt", "version.txt")
	if FileAccess.file_exists(MOD_DIR + "mods.pck"):
		if not ProjectSettings.load_resource_pack(MOD_DIR + "mods.pck", true):
			push_warning("Idle Cultivation Mod: could not load mods.pck")
	ProjectSettings.set_setting("autoload/MainChar", "*res://Data/Char/MainChar.gd")
	real_script = load("res://Data/Char/MainChar.gd")
	Engine.get_main_loop().node_added.connect(_swap)

static func _swap(n: Node) -> void:
	if n.name == &"MainChar" and real_script != null:
		Engine.get_main_loop().node_added.disconnect(_swap)
		var s := real_script
		real_script = null
		n.set_script(s)
