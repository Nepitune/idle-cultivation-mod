Idle Cultivation Mod
====================

INSTALL (once)
1. In Steam: right-click Idle Cultivation > Manage > Browse local files.
2. Extract this zip into that folder (a subfolder like IdleCultivationMod
   inside the game folder is fine too).
3. Double-click install.bat.
4. Start the game through Steam as usual.

UPDATES
When a new version is published, a popup appears a moment after the game
has loaded. "Install" downloads it (a few seconds); it becomes active the
next time you start the game. "Not now" asks again next start.
No internet = no popup, the game starts normally.

UNINSTALL
Double-click uninstall.bat. Your saves are not touched.

The mod only works with the current game version.
