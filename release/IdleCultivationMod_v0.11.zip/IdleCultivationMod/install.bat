@echo off
setlocal
cd /d "%~dp0"
echo === Idle Cultivation Mod installer ===
set "GAMEDIR=%~dp0"
if not exist "IdleCultivation.exe" if exist "..\IdleCultivation.exe" set "GAMEDIR=%~dp0..\"
if not exist "%GAMEDIR%IdleCultivation.exe" (
  echo.
  echo This file must be inside the Idle Cultivation game folder,
  echo next to IdleCultivation.exe. In Steam: right-click the game,
  echo Manage, Browse local files. Copy everything from this zip there.
  pause
  exit /b 1
)
if not exist "mods\mods.pck" (
  echo The "mods" folder from the zip is missing next to install.bat.
  pause
  exit /b 1
)
set "MODDIR=%APPDATA%\Godot\app_userdata\Idle Cultivation\mods"
if not exist "%MODDIR%" mkdir "%MODDIR%"
del /q "%MODDIR%\mods_pending.pck" "%MODDIR%\pending_version.txt" "%MODDIR%\mods_download.tmp" 2>nul
copy /y "mods\boot.gd" "%MODDIR%\boot.gd" >nul
copy /y "mods\mods.pck" "%MODDIR%\mods.pck" >nul
copy /y "mods\version.txt" "%MODDIR%\version.txt" >nul
copy /y "mods\override.cfg" "%GAMEDIR%override.cfg" >nul
if exist "%GAMEDIR%IdleCultivation.pck.original" (
  copy /y "%GAMEDIR%IdleCultivation.pck.original" "%GAMEDIR%IdleCultivation.pck" >nul
  echo Restored the original game file from the old patch backup.
)
echo.
echo Installed. Start the game normally through Steam.
echo Future updates will be offered inside the game.
pause
