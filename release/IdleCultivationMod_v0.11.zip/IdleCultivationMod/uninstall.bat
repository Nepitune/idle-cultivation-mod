@echo off
setlocal
cd /d "%~dp0"
del /q "override.cfg" 2>nul
del /q "..\override.cfg" 2>nul
rmdir /s /q "%APPDATA%\Godot\app_userdata\Idle Cultivation\mods" 2>nul
echo The mod is removed. Your save files were not touched.
pause
